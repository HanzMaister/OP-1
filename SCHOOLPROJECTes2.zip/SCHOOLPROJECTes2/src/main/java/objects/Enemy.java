package objects;

import main.GamePanel;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.time.chrono.ThaiBuddhistChronology;
import java.util.Random;

public class Enemy {
    public int x;
    public int y;
    public int width = 64;
    public int height = 64;
    public int speed = 8;
    int level;
    int hp;
    public BufferedImage image;


    public Rectangle rectangle;
    GamePanel gamePanel;
    public Enemy(GamePanel gamePanel){
        this.gamePanel = gamePanel;
        setDefaultValues();
        getEnemyImage();
    }
    public void setDefaultValues(){
        Random random = new Random();
        x = random.nextInt(gamePanel.width);
        y = 0;
        level = 1;
        hp = level * 2;

    }

    public void updatePosition(){
        y += speed;
        rectangle = new Rectangle(x , y -20, width, height);
    }
    public void getEnemyImage(){
        try {
            image = ImageIO.read(getClass().getResourceAsStream("/object/meteorite.png"));

        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void draw(Graphics g){
        g.drawImage(image,x,y,width,height, null);
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }
}
