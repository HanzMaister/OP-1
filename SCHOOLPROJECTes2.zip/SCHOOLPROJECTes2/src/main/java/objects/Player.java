package objects;

import main.GamePanel;
import main.KeyReader;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Player {
    public int x;
    public int y;
    public int width = 64;
    public int height = 64;
    public int speed = 6;
    public BufferedImage image;
    public Rectangle solidRect;
    GamePanel gamePanel;
    KeyReader keyReader;

    public Player(GamePanel gamePanel, KeyReader keyReader){
        this.gamePanel = gamePanel;
        this.keyReader = keyReader;
        setDefaultValues();
        getPlayerImage();
    }
    public void setDefaultValues(){
        x = 300;
        y = 300;
    }
    public void update(){
        if(keyReader.uPressed == true) {
            y -= speed;
        }
        if(keyReader.downPressed == true) {
            y += speed;
        }
        if(keyReader.leftPressed == true){
            x -= speed;
        }
        if(keyReader.rightPressed == true){
            x += speed;
        }
        solidRect = new Rectangle(x + 20, y + 20,  width -40, height - 10 );
    }
    public void getPlayerImage(){
        try {
            image = ImageIO.read(getClass().getResourceAsStream("/object/Rocket.png"));
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    public void draw (Graphics g){
        g.drawImage(image, x, y, width, height, null);

    }
}
